---
marp: true
theme: default
paginate: true
style: |
  section { background: #121212; color: white; font-size: 32px; }
  h1 { color: #00ADB5; }
---

# The Missing Skill
Nobody teaches conversation management.

---

# Real Conversation Is Messy
People:
- Ask follow-ups
- Redirect topics
- Stall for time
- Clarify confusion
- Buy thinking time

---

# But Apps Pretend
Conversation = Words + Grammar

---

# Reality
Conversation is its own skill.

---

# My Obsession
What if we trained Chinese
like a practical skill?

---

# What If...
We trained the mechanics of conversation itself?

---

# My Experiment
I'm building something to test this.

---

# Coming Soon
10-Day Public Challenge.
