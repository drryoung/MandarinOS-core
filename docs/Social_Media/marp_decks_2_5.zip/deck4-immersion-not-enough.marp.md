---
marp: true
theme: default
paginate: true
style: |
  section { background: #121212; color: white; font-size: 32px; }
  h1 { color: #00ADB5; }
---

# Why Immersion Isn't Enough
"Just speak more."

Everyone says this.

---

# My Reality
I have a Chinese wife.

Daily native exposure.

Still struggled.

---

# So What's Wrong?
Immersion assumes you can survive inside the conversation.

---

# What Actually Happens
- Someone speaks fast
- You partly miss it
- Panic kicks in
- You mentally translate
- Confidence drops
- Switch to English

---

# That's Not Immersion
That's survival mode.

---

# Swimming Analogy
Throwing someone in deep water
doesn't teach them to swim calmly.

---

# Real Missing Skill
Nobody teaches how to survive when things go wrong.
