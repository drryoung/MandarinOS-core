---
marp: true
theme: default
paginate: true
style: |
  section { background: #121212; color: white; font-size: 32px; }
  h1 { color: #00ADB5; }
---

# Why Apps Don't Teach Speaking
Most apps train recognition.

Not conversation.

---

# Think About It
What do apps make you do?
- Match sentences
- Tap translations
- Fill blanks
- Reorder words

---

# The Problem
The answer is always in front of you.

---

# Recognition vs Generation
Recognising Chinese ≠ Producing Chinese.

---

# Real Conversation
No hints.
No multiple choice.
No sentence bank.

---

# Driving Analogy
Passing theory ≠ Driving in traffic.

---

# Why Learners Plateau
They get good at recognising...

But never train generation.
