---
marp: true
theme: default
paginate: true
style: |
  section { background: #121212; color: white; font-size: 32px; }
  h1 { color: #00ADB5; }
---

# The Vocabulary Trap
Knowing words is NOT the same as speaking.

---

# My Realisation
If vocabulary alone made you fluent...

Every intermediate learner would already be conversational.

---

# But They're Not
Most know enough words for basic conversation.

Yet still freeze.

---

# Why?
Conversation requires your brain to:
- Understand instantly
- Search memory
- Build sentence
- Check grammar
- Pronounce correctly

All in 2 seconds.

---

# That's Not Knowledge
That's **performance under pressure**.

---

# Basketball Analogy
Knowing the rules ≠ Playing the game.

---

# The Real Problem
We don't have a knowledge problem.

We have a **training problem**.

---

# Conclusion
We never train rapid retrieval under pressure.
